package com.allhotplace.www.service.face.chatbot;

import java.util.List;

import com.allhotplace.www.dto.JChatbot;

public interface ChatBotService {

	public List<JChatbot> reply(String content);

//	public List answer();
}
