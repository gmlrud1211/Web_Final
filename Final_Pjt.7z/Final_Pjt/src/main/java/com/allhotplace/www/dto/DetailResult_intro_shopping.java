package com.allhotplace.www.dto;

public class DetailResult_intro_shopping {
	
	
//	검색결과 페이지에서 API 호출 시 값 전달을 위한 DTO

	private String chkbabycarriageshopping;
	private String chkcreditcard;
	private String shopping;
	private String chkpetshopping;
	private String culturecenter;
	private String fairday;
	private String infocentershopping;
	private String opendateshopping;
	private String opentime;
	private String parkingshopping;
	private String restdateshopping;
	private String restroom;
	private String saleitem;
	private String saleitemcost;
	private String scaleshopping;
	private String shopguide;
	public String getChkbabycarriageshopping() {
		return chkbabycarriageshopping;
	}
	public String getChkcreditcard() {
		return chkcreditcard;
	}
	public String getShopping() {
		return shopping;
	}
	public String getChkpetshopping() {
		return chkpetshopping;
	}
	public String getCulturecenter() {
		return culturecenter;
	}
	public String getFairday() {
		return fairday;
	}
	public String getInfocentershopping() {
		return infocentershopping;
	}
	public String getOpendateshopping() {
		return opendateshopping;
	}
	public String getOpentime() {
		return opentime;
	}
	public String getParkingshopping() {
		return parkingshopping;
	}
	public String getRestdateshopping() {
		return restdateshopping;
	}
	public String getRestroom() {
		return restroom;
	}
	public String getSaleitem() {
		return saleitem;
	}
	public String getSaleitemcost() {
		return saleitemcost;
	}
	public String getScaleshopping() {
		return scaleshopping;
	}
	public String getShopguide() {
		return shopguide;
	}
	public void setChkbabycarriageshopping(String chkbabycarriageshopping) {
		this.chkbabycarriageshopping = chkbabycarriageshopping;
	}
	public void setChkcreditcard(String chkcreditcard) {
		this.chkcreditcard = chkcreditcard;
	}
	public void setShopping(String shopping) {
		this.shopping = shopping;
	}
	public void setChkpetshopping(String chkpetshopping) {
		this.chkpetshopping = chkpetshopping;
	}
	public void setCulturecenter(String culturecenter) {
		this.culturecenter = culturecenter;
	}
	public void setFairday(String fairday) {
		this.fairday = fairday;
	}
	public void setInfocentershopping(String infocentershopping) {
		this.infocentershopping = infocentershopping;
	}
	public void setOpendateshopping(String opendateshopping) {
		this.opendateshopping = opendateshopping;
	}
	public void setOpentime(String opentime) {
		this.opentime = opentime;
	}
	public void setParkingshopping(String parkingshopping) {
		this.parkingshopping = parkingshopping;
	}
	public void setRestdateshopping(String restdateshopping) {
		this.restdateshopping = restdateshopping;
	}
	public void setRestroom(String restroom) {
		this.restroom = restroom;
	}
	public void setSaleitem(String saleitem) {
		this.saleitem = saleitem;
	}
	public void setSaleitemcost(String saleitemcost) {
		this.saleitemcost = saleitemcost;
	}
	public void setScaleshopping(String scaleshopping) {
		this.scaleshopping = scaleshopping;
	}
	public void setShopguide(String shopguide) {
		this.shopguide = shopguide;
	}
	@Override
	public String toString() {
		return "DetailResult_intro_shopping [chkbabycarriageshopping=" + chkbabycarriageshopping + ", chkcreditcard="
				+ chkcreditcard + ", shopping=" + shopping + ", chkpetshopping=" + chkpetshopping + ", culturecenter="
				+ culturecenter + ", fairday=" + fairday + ", infocentershopping=" + infocentershopping
				+ ", opendateshopping=" + opendateshopping + ", opentime=" + opentime + ", parkingshopping="
				+ parkingshopping + ", restdateshopping=" + restdateshopping + ", restroom=" + restroom + ", saleitem="
				+ saleitem + ", saleitemcost=" + saleitemcost + ", scaleshopping=" + scaleshopping + ", shopguide="
				+ shopguide + "]";
	}

	
}
