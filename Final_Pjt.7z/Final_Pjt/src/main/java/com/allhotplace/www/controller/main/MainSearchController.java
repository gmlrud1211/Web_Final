package com.allhotplace.www.controller.main;

public class MainSearchController {

}
