package com.allhotplace.www.dao.face.main;

import java.util.List;

public interface MainDao {

	public List totalsearch();



}
